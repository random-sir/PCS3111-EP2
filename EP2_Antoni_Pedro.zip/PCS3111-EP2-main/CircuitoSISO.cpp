#include "CircuitoSISO.h"

CircuitoSISO::CircuitoSISO(){
}

CircuitoSISO::~CircuitoSISO(){
}
