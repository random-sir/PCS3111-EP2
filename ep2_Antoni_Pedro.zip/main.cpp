void menu();
/*void testaSinal();
void testaSomador();
void testaDerivador();
void testaIntegrador();
void testaAmplificador();
void testaPiloto();
void testaModuloRealimentado();*/

int main(){
  menu();
  return 0;
}
