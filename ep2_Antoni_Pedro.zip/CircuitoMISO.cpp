#include "CircuitoMISO.h"

CircuitoMISO::CircuitoMISO(){
}

CircuitoMISO::~CircuitoMISO(){
}
